import json
import random
import os
from nonebot import on_command
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, MessageSegment

# 获取当前文件所在的目录路径
plugin_path = os.path.dirname(__file__)

# 构建 data.json 文件的相对路径
DATA_FILE_PATH = os.path.join(plugin_path, "data.json")

# 加载存储的用户数据
def load_user_data(group_id: str):
    try:
        with open(DATA_FILE_PATH, "r", encoding="utf-8") as file:
            data = json.load(file)
            # 返回指定群的用户数据
            return data.get(str(group_id), {})
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

# 保存用户数据
def save_user_data(group_id: str, data):
    try:
        # 加载现有数据
        with open(DATA_FILE_PATH, "r", encoding="utf-8") as file:
            all_data = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        all_data = {}

    # 确保每个群号下的数据是一个字典，并且保存当前数据
    if str(group_id) not in all_data:
        all_data[str(group_id)] = {}

    # 更新指定群的数据
    all_data[str(group_id)].update(data)

    # 保存数据到文件
    with open(DATA_FILE_PATH, "w", encoding="utf-8") as file:
        json.dump(all_data, file, ensure_ascii=False, indent=4)

# 定义命令装饰器
Gwife = on_command("群老婆", aliases={"Gwife"}, priority=5)

@Gwife.handle()
async def random_user_avatar(bot: Bot, event: GroupMessageEvent):
    event_data = json.loads(event.json()) if isinstance(event.json(), str) else event.json()
    group_id = event_data.get("group_id", None)  # 获取群ID
    user_id = event_data.get("user_id", None)  # 获取用户ID
    avatar_url = event_data.get("avatar", None)  # 获取用户头像URL

    # 如果头像 URL 存在
    if avatar_url:
        # 加载现有群数据
        group_data = load_user_data(group_id)

        # 存储用户 ID 和头像 URL
        group_data[str(user_id)] = avatar_url
        
        # 保存群数据到文件
        save_user_data(group_id, group_data)
        print(f"已存储群 {group_id} 用户 {user_id} 的头像：{avatar_url}")

        # 加载存储的群数据
        selected_user_id = random.choice(list(group_data.keys()))
        selected_avatar_url = group_data[selected_user_id]

        # 获取用户昵称
        user_info = await bot.get_group_member_info(group_id=event.group_id, user_id=int(selected_user_id))
        user_nickname = user_info.get("nickname", "未知")
        
        message = MessageSegment.at(selected_user_id) + f"\n你今天的老婆是\n@{user_nickname} 啊！" + MessageSegment.image(selected_avatar_url)

        # 发送对应用户的头像及昵称
        await bot.send(event, message)
    else:
        await bot.send(event, "无法获取你的头像！")
